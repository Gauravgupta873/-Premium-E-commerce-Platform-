
// Currency conversion utility
const USD_TO_INR_RATE = 83.12; // Current approximate rate

export const convertToINR = (usdPrice: number): number => {
  return Math.round(usdPrice * USD_TO_INR_RATE);
};

export const formatINR = (price: number): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(price);
};

export const formatUSDToINR = (usdPrice: number): string => {
  const inrPrice = convertToINR(usdPrice);
  return formatINR(inrPrice);
};
