
import { useState, useEffect } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ProductCard from '@/components/ProductCard';
import ProductModal from '@/components/ProductModal';
import { Product } from '@/types/product';
import { useAuth } from '@/hooks/useAuth';
import { useWishlist } from '@/hooks/useWishlist';
import { allProducts } from '@/data/products';
import { Heart } from 'lucide-react';

const Wishlist = () => {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [wishlistProducts, setWishlistProducts] = useState<Product[]>([]);
  const { user } = useAuth();
  const { wishlistItems, loading } = useWishlist();

  useEffect(() => {
    if (wishlistItems.length > 0) {
      const products = allProducts.filter(product => 
        wishlistItems.includes(product.id)
      );
      setWishlistProducts(products);
    } else {
      setWishlistProducts([]);
    }
  }, [wishlistItems]);

  if (!user) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
          <Heart className="h-24 w-24 text-gray-300 mx-auto mb-6" />
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Sign In Required</h1>
          <p className="text-lg text-gray-600">
            Please sign in to view your wishlist items.
          </p>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-purple-500 to-pink-500 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl lg:text-6xl font-bold mb-6">My Wishlist</h1>
          <p className="text-xl lg:text-2xl mb-8 max-w-3xl mx-auto">
            Your favorite items saved for later
          </p>
        </div>
      </section>

      {/* Wishlist Items */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {loading ? (
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900 mx-auto"></div>
              <p className="mt-4 text-gray-600">Loading your wishlist...</p>
            </div>
          ) : wishlistProducts.length > 0 ? (
            <>
              <div className="text-center mb-12">
                <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                  {wishlistProducts.length} {wishlistProducts.length === 1 ? 'Item' : 'Items'} in Your Wishlist
                </h2>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {wishlistProducts.map((product) => (
                  <ProductCard 
                    key={product.id} 
                    product={product} 
                    onClick={() => setSelectedProduct(product)}
                  />
                ))}
              </div>
            </>
          ) : (
            <div className="text-center py-20">
              <Heart className="h-24 w-24 text-gray-300 mx-auto mb-6" />
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Your Wishlist is Empty</h2>
              <p className="text-lg text-gray-600 mb-8">
                Start adding items you love to see them here
              </p>
            </div>
          )}
        </div>
      </section>

      <Footer />

      {selectedProduct && (
        <ProductModal
          product={selectedProduct}
          isOpen={!!selectedProduct}
          onClose={() => setSelectedProduct(null)}
        />
      )}
    </div>
  );
};

export default Wishlist;
