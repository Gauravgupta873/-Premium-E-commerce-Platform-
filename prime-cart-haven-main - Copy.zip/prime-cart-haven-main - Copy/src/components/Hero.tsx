
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative bg-gradient-to-r from-gray-900 to-black text-white overflow-hidden">
      <div className="absolute inset-0 bg-black/20"></div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
        <div className="max-w-3xl">
          <h1 className="text-4xl lg:text-6xl font-bold mb-6 leading-tight">
            Premium Products,
            <span className="text-yellow-400 block">Exceptional Prices</span>
          </h1>
          <p className="text-xl text-gray-300 mb-8 leading-relaxed">
            Discover luxury items from top brands at unbeatable discounts. 
            Limited time offers on curated premium collections.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            {/* 
            {<Button size="lg" className="bg-yellow-400 text-black hover:bg-yellow-300 font-semibold">
              Shop Now
              <ArrowRight className="ml-2 h-5 w-5" />

            </Button>
            <Button size="lg" variant="outline" className="border-white text-black hover:bg-white hover:text-black">
              View Collections
            </Button>}
            */}
          </div>
        </div>
      </div>
      
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1200&h=800&fit=crop" 
          alt="Luxury Shopping" 
          className="w-full h-full object-cover opacity-30"
        />
      </div>
    </section>
  );
};

export default Hero;
