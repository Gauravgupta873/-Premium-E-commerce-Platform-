import { useState } from 'react';
import { Search, ShoppingBag, Menu, User, Heart, LogOut } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { useCartStore } from '@/store/cartStore';
import { useAuth } from '@/hooks/useAuth';
import { useWishlist } from '@/hooks/useWishlist';
import CartSidebar from './CartSidebar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchBar, setShowSearchBar] = useState(false);
  const itemCount = useCartStore(state => state.getItemCount());

  const {
    user,
    signOut
  } = useAuth();
  const {
    wishlistItems
  } = useWishlist();
  const navigate = useNavigate();
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
      setSearchQuery('');
      setShowSearchBar(false);
    }
  };
  return <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex-shrink-0">
            <Link to="/">
              <h1 className="text-2xl font-bold text-black tracking-tight">G-Shop</h1>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <Link to="/electronics" className="text-gray-900 hover:text-gray-600 px-3 py-2 text-sm font-medium transition-colors">
              Electronics
            </Link>
            <Link to="/fashion" className="text-gray-900 hover:text-gray-600 px-3 py-2 text-sm font-medium transition-colors">
              Fashion
            </Link>
            <Link to="/accessories" className="text-gray-900 hover:text-gray-600 px-3 py-2 text-sm font-medium transition-colors">
              Accessories
            </Link>
            <Link to="/home" className="text-gray-900 hover:text-gray-600 px-3 py-2 text-sm font-medium transition-colors">
              Home & Living
            </Link>
            <Link to="/sale" className="text-gray-900 hover:text-gray-600 px-3 py-2 text-sm font-medium transition-colors">
              Sale
            </Link>
          </nav>

          {/* Search Bar (Desktop) */}
          {showSearchBar && <div className="hidden md:flex flex-1 max-w-md mx-8">
              <form onSubmit={handleSearch} className="w-full relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input type="text" placeholder="Search products..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="w-full pl-10 pr-4" autoFocus />
              </form>
            </div>}

          {/* Actions */}
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" className="hidden sm:flex" onClick={() => setShowSearchBar(!showSearchBar)}>
              <Search className="h-5 w-5" />
            </Button>
            
            <Link to="/wishlist">
              <Button variant="ghost" size="icon" className="hidden sm:flex relative">
                <Heart className="h-5 w-5" />
                {wishlistItems.length > 0 && <Badge className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 text-xs bg-red-500 text-white">
                    {wishlistItems.length}
                  </Badge>}
              </Button>
            </Link>
            
            {user ? <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <User className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem asChild>
                    <Link to="/wishlist" className="cursor-pointer">
                      <Heart className="h-4 w-4 mr-2" />
                      Wishlist
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={signOut}>
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu> : <Link to="/auth">
                <Button variant="ghost" size="icon">
                  <User className="h-5 w-5" />
                </Button>
              </Link>}

            <CartSidebar>
              <Button variant="ghost" size="icon" className="relative">
                <ShoppingBag className="h-5 w-5" />
                {itemCount > 0 && <Badge className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 text-xs bg-black text-white">
                    {itemCount}
                  </Badge>}
              </Button>
            </CartSidebar>

            <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Mobile Search */}
        {showSearchBar && <div className="md:hidden pb-4">
            <form onSubmit={handleSearch} className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input type="text" placeholder="Search products..."  value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="w-full pl-10 pr-4" autoFocus />
              
            </form>
          </div>}

        {/* Mobile Menu */}
        {isMenuOpen && <div className="md:hidden border-t border-gray-200 py-4">
            <div className="flex flex-col space-y-2">
              <Link to="/electronics" className="text-gray-900 hover:text-gray-600 px-3 py-2 text-sm font-medium">
                Electronics
              </Link>
              <Link to="/fashion" className="text-gray-900 hover:text-gray-600 px-3 py-2 text-sm font-medium">
                Fashion
              </Link>
              <Link to="/accessories" className="text-gray-900 hover:text-gray-600 px-3 py-2 text-sm font-medium">
                Accessories
              </Link>
              <Link to="/home" className="text-gray-900 hover:text-gray-600 px-3 py-2 text-sm font-medium">
                Home & Living
              </Link>
              <Link to="/sale" className="text-gray-900 hover:text-gray-600 px-3 py-2 text-sm font-medium">
                Sale
              </Link>
              <Link to="/search" className="text-gray-900 hover:text-gray-600 px-3 py-2 text-sm font-medium">
                Search
              </Link>
              <Link to="/wishlist" className="text-gray-900 hover:text-gray-600 px-3 py-2 text-sm font-medium">
                Wishlist ({wishlistItems.length})
              </Link>
            </div>
          </div>}
      </div>
    </header>;
};
export default Header;