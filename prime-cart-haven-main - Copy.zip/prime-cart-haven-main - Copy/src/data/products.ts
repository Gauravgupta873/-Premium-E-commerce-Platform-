
import { Product } from '@/types/product';

export const featuredProducts: Product[] = [
  {
    id: '1',
    name: 'Premium Wireless Headphones',
    brand: 'AudioLux',
    price: 299,
    originalPrice: 499,
    discount: 40,
    images: [
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=500&h=500&fit=crop'
    ],
    category: 'Electronics',
    description: 'Experience unparalleled sound quality with our flagship wireless headphones featuring active noise cancellation and 30-hour battery life.',
    features: ['Active Noise Cancellation', '30-hour Battery', 'Premium Leather', 'Wireless Charging'],
    inStock: true,
    rating: 4.8,
    reviews: 1247
  },
  {
    id: '2',
    name: 'Luxury Smartwatch',
    brand: 'ChronoTech',
    price: 799,
    originalPrice: 1199,
    discount: 33,
    images: [
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1544117519-31a4b719223d?w=500&h=500&fit=crop'
    ],
    category: 'Electronics',
    description: 'Crafted with precision and elegance, this luxury smartwatch combines traditional watchmaking with cutting-edge technology.',
    features: ['Sapphire Crystal', 'Titanium Case', 'Heart Rate Monitor', 'GPS Tracking'],
    inStock: true,
    rating: 4.9,
    reviews: 892
  },
  {
    id: '3',
    name: 'Designer Sunglasses',
    brand: 'VisionCraft',
    price: 449,
    originalPrice: 649,
    discount: 31,
    images: [
      'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=500&h=500&fit=crop'
    ],
    category: 'Accessories',
    description: 'Handcrafted designer sunglasses with polarized lenses and premium acetate frames for the ultimate in style and protection.',
    features: ['Polarized Lenses', 'Acetate Frames', 'UV Protection', 'Scratch Resistant'],
    inStock: true,
    rating: 4.7,
    reviews: 634
  },
  {
    id: '4',
    name: 'Premium Leather Bag',
    brand: 'CraftLux',
    price: 899,
    originalPrice: 1299,
    discount: 31,
    images: [
      'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500&h=500&fit=crop',
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=500&h=500&fit=crop'
    ],
    category: 'Fashion',
    description: 'Exquisite full-grain leather bag meticulously crafted by master artisans. Perfect for business or travel.',
    features: ['Full-Grain Leather', 'Hand-Stitched', 'Multiple Compartments', 'Lifetime Warranty'],
    inStock: true,
    rating: 4.9,
    reviews: 421
  }
];

export const electronicsProducts: Product[] = [
  ...featuredProducts.filter(p => p.category === 'Electronics'),
  {
    id: '5',
    name: 'Wireless Earbuds Pro',
    brand: 'SoundElite',
    price: 199,
    originalPrice: 299,
    discount: 33,
    images: [
      'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=500&h=500&fit=crop'
    ],
    category: 'Electronics',
    description: 'Premium wireless earbuds with exceptional sound quality and seamless connectivity.',
    features: ['Active Noise Cancellation', 'Wireless Charging', '8-hour Battery', 'Water Resistant'],
    inStock: true,
    rating: 4.6,
    reviews: 892
  },
  {
    id: '6',
    name: '4K Action Camera',
    brand: 'AdventurePro',
    price: 349,
    originalPrice: 499,
    discount: 30,
    images: [
      'https://images.unsplash.com/photo-1606983340126-99ab4feaa64a?w=500&h=500&fit=crop'
    ],
    category: 'Electronics',
    description: 'Capture your adventures in stunning 4K resolution with this waterproof action camera.',
    features: ['4K Recording', 'Waterproof', 'Image Stabilization', 'WiFi Connectivity'],
    inStock: true,
    rating: 4.5,
    reviews: 567
  },
  {
    id: '7',
    name: 'Gaming Mechanical Keyboard',
    brand: 'KeyMaster',
    price: 129,
    originalPrice: 199,
    discount: 35,
    images: [
      'https://images.unsplash.com/photo-1541140532154-b024d705b90a?w=500&h=500&fit=crop'
    ],
    category: 'Electronics',
    description: 'Professional gaming keyboard with mechanical switches and RGB backlighting.',
    features: ['Mechanical Switches', 'RGB Backlighting', 'Programmable Keys', 'Anti-Ghosting'],
    inStock: true,
    rating: 4.7,
    reviews: 1123
  }
];

export const fashionProducts: Product[] = [
  ...featuredProducts.filter(p => p.category === 'Fashion'),
  {
    id: '8',
    name: 'Silk Evening Dress',
    brand: 'ElegantCouture',
    price: 599,
    originalPrice: 899,
    discount: 33,
    images: [
      'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=500&h=500&fit=crop'
    ],
    category: 'Fashion',
    description: 'Luxurious silk evening dress perfect for special occasions and elegant events.',
    features: ['100% Silk', 'Hand-Tailored', 'Elegant Design', 'Premium Quality'],
    inStock: true,
    rating: 4.8,
    reviews: 234
  },
  {
    id: '9',
    name: 'Cashmere Sweater',
    brand: 'WarmLux',
    price: 299,
    originalPrice: 449,
    discount: 33,
    images: [
      'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=500&h=500&fit=crop'
    ],
    category: 'Fashion',
    description: 'Ultra-soft cashmere sweater that combines comfort with sophisticated style.',
    features: ['100% Cashmere', 'Luxury Comfort', 'Classic Design', 'Premium Warmth'],
    inStock: true,
    rating: 4.9,
    reviews: 445
  },
  {
    id: '10',
    name: 'Designer Jeans',
    brand: 'DenimCraft',
    price: 189,
    originalPrice: 289,
    discount: 35,
    images: [
      'https://images.unsplash.com/photo-1542272604-787c3835535d?w=500&h=500&fit=crop'
    ],
    category: 'Fashion',
    description: 'Premium designer jeans crafted from the finest denim with perfect fit and comfort.',
    features: ['Premium Denim', 'Perfect Fit', 'Stylish Design', 'Durable Quality'],
    inStock: true,
    rating: 4.6,
    reviews: 678
  }
];

export const accessoriesProducts: Product[] = [
  ...featuredProducts.filter(p => p.category === 'Accessories'),
  {
    id: '11',
    name: 'Minimalist Wallet',
    brand: 'SlimCraft',
    price: 89,
    originalPrice: 149,
    discount: 40,
    images: [
      'https://images.unsplash.com/photo-1627123424574-724758594e93?w=500&h=500&fit=crop'
    ],
    category: 'Accessories',
    description: 'Ultra-slim leather wallet designed for the modern minimalist.',
    features: ['RFID Blocking', 'Premium Leather', 'Slim Design', 'Lifetime Warranty'],
    inStock: true,
    rating: 4.5,
    reviews: 267
  },
  {
    id: '12',
    name: 'Luxury Watch',
    brand: 'TimeCraft',
    price: 1299,
    originalPrice: 1899,
    discount: 32,
    images: [
      'https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=500&h=500&fit=crop'
    ],
    category: 'Accessories',
    description: 'Swiss-made luxury watch with automatic movement and sapphire crystal.',
    features: ['Swiss Movement', 'Sapphire Crystal', 'Water Resistant', 'Leather Strap'],
    inStock: true,
    rating: 4.9,
    reviews: 156
  },
  {
    id: '13',
    name: 'Designer Scarf',
    brand: 'SilkLux',
    price: 149,
    originalPrice: 229,
    discount: 35,
    images: [
      'https://images.unsplash.com/photo-1601762603339-fd61e28b698a?w=500&h=500&fit=crop'
    ],
    category: 'Accessories',
    description: 'Elegant silk scarf with unique patterns, perfect for any outfit.',
    features: ['100% Silk', 'Unique Design', 'Versatile Style', 'Premium Quality'],
    inStock: true,
    rating: 4.7,
    reviews: 334
  }
];

export const homeLivingProducts: Product[] = [
  {
    id: '14',
    name: 'Modern Floor Lamp',
    brand: 'LightCraft',
    price: 399,
    originalPrice: 599,
    discount: 33,
    images: [
      'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=500&h=500&fit=crop'
    ],
    category: 'Home & Living',
    description: 'Contemporary floor lamp with adjustable brightness and elegant design.',
    features: ['LED Technology', 'Adjustable Brightness', 'Modern Design', 'Energy Efficient'],
    inStock: true,
    rating: 4.6,
    reviews: 445
  },
  {
    id: '15',
    name: 'Premium Throw Pillow',
    brand: 'ComfortLux',
    price: 79,
    originalPrice: 129,
    discount: 39,
    images: [
      'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=500&h=500&fit=crop'
    ],
    category: 'Home & Living',
    description: 'Luxuriously soft throw pillow that adds comfort and style to any room.',
    features: ['Premium Fabric', 'Hypoallergenic', 'Machine Washable', 'Elegant Design'],
    inStock: true,
    rating: 4.8,
    reviews: 267
  },
  {
    id: '16',
    name: 'Ceramic Vase Set',
    brand: 'ArtCraft',
    price: 149,
    originalPrice: 229,
    discount: 35,
    images: [
      'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=500&h=500&fit=crop'
    ],
    category: 'Home & Living',
    description: 'Handcrafted ceramic vase set perfect for displaying fresh flowers or as decorative pieces.',
    features: ['Handcrafted', 'Premium Ceramic', 'Set of 3', 'Elegant Design'],
    inStock: true,
    rating: 4.7,
    reviews: 189
  },
  {
    id: '17',
    name: 'Luxury Candle Collection',
    brand: 'AromaLux',
    price: 199,
    originalPrice: 299,
    discount: 33,
    images: [
      'https://images.unsplash.com/photo-1602874801006-e24cc9d09d15?w=500&h=500&fit=crop'
    ],
    category: 'Home & Living',
    description: 'Premium scented candle collection with natural soy wax and essential oils.',
    features: ['Natural Soy Wax', 'Essential Oils', 'Long Burning', 'Luxury Packaging'],
    inStock: true,
    rating: 4.9,
    reviews: 345
  }
];

export const saleProducts: Product[] = [
  // High discount items from all categories
  {
    id: '18',
    name: 'Bluetooth Speaker',
    brand: 'SoundWave',
    price: 99,
    originalPrice: 199,
    discount: 50,
    images: [
      'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=500&h=500&fit=crop'
    ],
    category: 'Electronics',
    description: 'Portable Bluetooth speaker with powerful sound and waterproof design.',
    features: ['Waterproof', 'Long Battery Life', 'Portable Design', 'Rich Sound'],
    inStock: true,
    rating: 4.4,
    reviews: 567
  },
  {
    id: '19',
    name: 'Summer Dress',
    brand: 'FashionForward',
    price: 79,
    originalPrice: 159,
    discount: 50,
    images: [
      'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=500&h=500&fit=crop'
    ],
    category: 'Fashion',
    description: 'Light and breezy summer dress perfect for warm weather occasions.',
    features: ['Breathable Fabric', 'Comfortable Fit', 'Versatile Style', 'Easy Care'],
    inStock: true,
    rating: 4.5,
    reviews: 432
  },
  {
    id: '20',
    name: 'Leather Belt',
    brand: 'StyleCraft',
    price: 59,
    originalPrice: 119,
    discount: 50,
    images: [
      'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500&h=500&fit=crop'
    ],
    category: 'Accessories',
    description: 'Classic leather belt with premium buckle, perfect for formal and casual wear.',
    features: ['Genuine Leather', 'Adjustable Size', 'Classic Design', 'Durable Quality'],
    inStock: true,
    rating: 4.6,
    reviews: 289
  },
  {
    id: '21',
    name: 'Wall Art Print',
    brand: 'ArtStudio',
    price: 49,
    originalPrice: 99,
    discount: 51,
    images: [
      'https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=500&h=500&fit=crop'
    ],
    category: 'Home & Living',
    description: 'Modern wall art print that adds personality and style to any room.',
    features: ['High Quality Print', 'Modern Design', 'Ready to Hang', 'Fade Resistant'],
    inStock: true,
    rating: 4.7,
    reviews: 156
  }
];

export const allProducts: Product[] = [
  ...featuredProducts,
  ...electronicsProducts,
  ...fashionProducts,
  ...accessoriesProducts,
  ...homeLivingProducts,
  ...saleProducts
];
